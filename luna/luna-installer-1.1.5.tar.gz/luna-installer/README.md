How To Install (Works for Polish, crated for debian/Ubuntu)
1.Unpack .tar.gz file
2.Go to luna-installer folder in terminal
3.Type ./luna-installer.sh run installer
4.Answer questions
5.Use luna command

For Other help ask in comments

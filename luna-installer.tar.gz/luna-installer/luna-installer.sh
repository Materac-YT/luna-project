
#!/bin/bash

if [[ $1 == "run" ]]; then

	if [[ $2 == "installer" ]]; then

	SKRYPT_DIR="$(dirname "$(realpath "${BASH_SOURCE[0]}")")"

	echo "Przygotowywanie Katalogów Instalacji..."
	cd ~
	mkdir luna
	cd luna
	rm luna.sh
	mkdir json
	cd json
	mkdir goto
	mkdir run
	mkdir open
	echo "Gotowe..."

	echo "Kopiowanie Plików..."
	cd /
	cp $SKRYPT_DIR/luna/luna.sh ~/luna/luna.sh
	cp $SKRYPT_DIR/luna/luna.json ~/luna/luna.json
	cp $SKRYPT_DIR/luna/app.json ~/luna/app.json
	cp $SKRYPT_DIR/luna/json/goto/folder.json ~/luna/json/goto/folder_1.json
	cp $SKRYPT_DIR/luna/json/goto/folder.json ~/luna/json/goto/folder_2.json
	cp $SKRYPT_DIR/luna/json/goto/folder.json ~/luna/json/goto/folder_3.json
	cp $SKRYPT_DIR/luna/json/goto/folder.json ~/luna/json/goto/folder_4.json
	cp $SKRYPT_DIR/luna/json/goto/folder.json ~/luna/json/goto/folder_5.json
	cp $SKRYPT_DIR/luna/json/open/file.json ~/luna/json/open/file_1.json
	cp $SKRYPT_DIR/luna/json/open/file.json ~/luna/json/open/file_2.json
	cp $SKRYPT_DIR/luna/json/open/file.json ~/luna/json/open/file_3.json
	cp $SKRYPT_DIR/luna/json/open/file.json ~/luna/json/open/file_4.json
	cp $SKRYPT_DIR/luna/json/open/file.json ~/luna/json/open/file_5.json
	cp $SKRYPT_DIR/luna/json/run/program.json ~/luna/json/run/program_1.json
	cp $SKRYPT_DIR/luna/json/run/program.json ~/luna/json/run/program_2.json
	cp $SKRYPT_DIR/luna/json/run/program.json ~/luna/json/run/program_3.json
	cp $SKRYPT_DIR/luna/json/run/program.json ~/luna/json/run/program_4.json
	cp $SKRYPT_DIR/luna/json/run/program.json ~/luna/json/run/program_5.json
	echo "Zrobione..."



	echo 'alias luna="source ~/luna/luna.sh"' >> ~/.bashrc
	source ~/.bashrc


	else

	echo "Użycie: ./luna-installer.sh run installer"

	fi

else

echo "Użycie: ./luna-installer.sh run installer"

fi
